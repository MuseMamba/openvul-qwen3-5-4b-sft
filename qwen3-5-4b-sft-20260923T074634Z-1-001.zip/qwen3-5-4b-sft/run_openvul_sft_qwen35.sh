#!/usr/bin/env bash
# OpenVul → Qwen3.5-4B SFT（异地部署：不写死机器路径）
#
# 工作根目录：OPENVUL_WORKSPACE，未设置则用当前工作目录
# 脚本目录（找 prepare_sft_qwen35.py）始终用本文件所在目录，与 cwd 无关。
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ACTION="${1:-all}"

if [[ -n "${OPENVUL_WORKSPACE:-}" ]]; then
  ROOT="${OPENVUL_WORKSPACE}"
else
  ROOT="$(pwd)"
fi
ROOT="$(cd "$ROOT" && pwd)"

CODE="${OPEN_VUL_CODE:-$ROOT/code/OpenVul}"
DATA="${OPEN_VUL_DATA:-$ROOT/data}"
MODELS="${OPEN_VUL_MODELS:-$ROOT/models}"
CLEAN="${DATA}/sft_qwen35"
HF_SFT_DIR="${DATA}/sft_reject"
PREPARE_PY="${PREPARE_PY:-$SCRIPT_DIR/prepare_sft_qwen35.py}"

MODEL_ID="${MODEL_ID:-Qwen/Qwen3.5-4B}"
SFT_REPO="${SFT_REPO:-Leopo1d/OpenVul_Rejection_Sampling_based_Vulnerability_Reasoning_Dataset_for_SFT}"
OUT_NAME="${OUT_NAME:-Qwen3.5-4B-OpenVul-SFT}"
MAX_LEN="${MAX_LEN:-32768}"
NUM_GPUS="${NUM_GPUS:-4}"
LR="${LR:-1e-5}"
WARMUP="${WARMUP:-0.1}"
WD="${WD:-0.01}"
EPOCHS="${EPOCHS:-5}"
GA="${GA:-8}"
PER_DEV_BS="${PER_DEV_BS:-1}"

log() { printf '\n==> %s\n' "$*"; }
die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

print_paths() {
  cat <<EOF
解析后的路径（可用环境变量覆盖）
  WORKSPACE     $ROOT
                覆盖: export OPENVUL_WORKSPACE=/abs/path
  CODE          $CODE
  DATA          $DATA
  MODELS        $MODELS
  PREPARE_PY    $PREPARE_PY
  MODEL_ID      $MODEL_ID
  MAX_LEN       $MAX_LEN
  NUM_GPUS      $NUM_GPUS
EOF
}

activate_env() {
  if [[ -f "${CODE}/.venv/bin/activate" ]]; then
    # shellcheck disable=SC1091
    source "${CODE}/.venv/bin/activate"
  elif [[ -f "${ROOT}/env/bin/activate" ]]; then
    # shellcheck disable=SC1091
    source "${ROOT}/env/bin/activate"
  else
    die "没有虚拟环境。先: bash $0 setup"
  fi
}

cmd_setup() {
  print_paths
  mkdir -p "$CODE" "$DATA" "$MODELS" "$CLEAN"
  if [[ ! -d "${CODE}/.git" ]]; then
    log "克隆 OpenVul -> $CODE"
    git clone https://github.com/youpengl/OpenVul.git "$CODE"
  else
    log "OpenVul 已存在: $CODE"
  fi
  cd "$CODE"
  python3 -m pip install -U uv
  uv python install 3.11.13 || true
  if [[ ! -f "${CODE}/.venv/bin/activate" ]]; then
    uv venv --python 3.11.13 || python3 -m venv "${CODE}/.venv"
  fi
  # shellcheck disable=SC1091
  source "${CODE}/.venv/bin/activate"
  uv pip install -r requirements.txt
  uv pip install -U datasets huggingface_hub transformers accelerate
  uv pip install flash-attn==2.8.1 --no-build-isolation || echo "WARN: flash-attn 失败，训练可改 sdpa"
  echo "setup ok"
}

cmd_download() {
  print_paths
  activate_env
  mkdir -p "$HF_SFT_DIR" "$MODELS"
  log "下载 SFT 数据 $SFT_REPO -> $HF_SFT_DIR"
  python3 - <<PY
from datasets import load_dataset
from pathlib import Path
dest = Path(r"${HF_SFT_DIR}")
dest.mkdir(parents=True, exist_ok=True)
marker = dest / "dataset_dict.json"
state = dest / "state.json"
if marker.exists() or state.exists():
    print("skip existing", dest)
else:
    ds = load_dataset("${SFT_REPO}")
    ds.save_to_disk(str(dest))
    print(ds)
PY
  local dest="${MODELS}/Qwen3.5-4B"
  log "下载基座 ${MODEL_ID} -> ${dest}"
  if [[ -f "${dest}/config.json" ]]; then
    echo "skip $dest"
  else
    if command -v hf >/dev/null 2>&1; then
      hf download "${MODEL_ID}" --local-dir "$dest"
    else
      huggingface-cli download "${MODEL_ID}" --local-dir "$dest"
    fi
  fi
}

cmd_clean() {
  print_paths
  activate_env
  [[ -d "$HF_SFT_DIR" ]] || die "没有 SFT 原始数据: $HF_SFT_DIR ；先 download"
  [[ -f "$PREPARE_PY" ]] || die "找不到清洗脚本: $PREPARE_PY （须和本 sh 放同一目录）"
  local tok="${MODELS}/Qwen3.5-4B"
  [[ -f "${tok}/config.json" ]] || tok="${MODEL_ID}"
  log "清洗 -> $CLEAN"
  python3 "$PREPARE_PY" \
    --src "$HF_SFT_DIR" \
    --dst "$CLEAN" \
    --tokenizer "$tok" \
    --max-length "$MAX_LEN"
}

cmd_train() {
  print_paths
  activate_env
  [[ -d "${CLEAN}/hf" ]] || die "没有清洗数据: ${CLEAN}/hf ；先 clean"
  local model="${MODELS}/Qwen3.5-4B"
  [[ -f "${model}/config.json" ]] || model="${MODEL_ID}"
  cd "$CODE"
  mkdir -p "outputs/${OUT_NAME}"
  local n_gpu
  n_gpu="$(nvidia-smi -L 2>/dev/null | wc -l || echo 0)"
  echo "可见 GPU=${n_gpu}  NUM_GPUS=${NUM_GPUS}"
  [[ "${n_gpu}" -ge 1 ]] || die "没有 GPU"
  [[ -n "${HF_TOKEN:-}" ]] || echo "WARN: 未设置 HF_TOKEN"

  local attn="flash_attention_2"
  python3 -c "import flash_attn" 2>/dev/null || attn="sdpa"

  local acc_cfg="examples/accelerate_configs/sft_zero3.yaml"
  [[ -f "$acc_cfg" ]] || acc_cfg=""

  log "SFT model=$model epochs=$EPOCHS lr=$LR max_len=$MAX_LEN attn=$attn"
  local cmd=(
    trl/scripts/sft.py
    --model_name_or_path "${model}"
    --run_name "${OUT_NAME}"
    --output_dir "outputs/${OUT_NAME}"
    --dataset_name "${CLEAN}/hf"
    --learning_rate "${LR}"
    --lr_scheduler_type linear
    --warmup_ratio "${WARMUP}"
    --weight_decay "${WD}"
    --num_train_epochs "${EPOCHS}"
    --bf16 true
    --torch_dtype bfloat16
    --gradient_checkpointing
    --attn_implementation "${attn}"
    --max_length "${MAX_LEN}"
    --per_device_train_batch_size "${PER_DEV_BS}"
    --per_device_eval_batch_size "${PER_DEV_BS}"
    --gradient_accumulation_steps "${GA}"
    --eval_strategy no
    --save_strategy epoch
    --logging_steps 1
    --log_level info
    --dataset_train_split train
    --report_to "${REPORT_TO:-none}"
    --gradient_checkpointing_kwargs '{"use_reentrant": false}'
    --trust_remote_code true
  )

  if [[ -n "$acc_cfg" ]]; then
    accelerate launch --config_file "$acc_cfg" "${cmd[@]}"
  else
    accelerate launch --num_processes "${NUM_GPUS}" "${cmd[@]}"
  fi
}

cmd_all() {
  cmd_setup
  cmd_download
  cmd_clean
  cmd_train
}

cmd_help() {
  cat <<EOF
用法:
  export OPENVUL_WORKSPACE=/任意绝对路径
  bash run_openvul_sft_qwen35.sh [setup|download|clean|train|all|paths]

路径规则（无机器默认路径）:
  OPENVUL_WORKSPACE  工作根；未设置则用当前目录

可选覆盖:
  OPEN_VUL_CODE OPEN_VUL_DATA OPEN_VUL_MODELS PREPARE_PY
  MODEL_ID MAX_LEN NUM_GPUS HF_TOKEN

示例（集群）:
  export OPENVUL_WORKSPACE=/data/openvul
  export HF_TOKEN=...
  mkdir -p "\$OPENVUL_WORKSPACE"
  bash /path/to/run_openvul_sft_qwen35.sh all
EOF
}

case "$ACTION" in
  help|-h|--help) cmd_help ;;
  paths) print_paths ;;
  setup) cmd_setup ;;
  download) cmd_download ;;
  clean) cmd_clean ;;
  train) cmd_train ;;
  all) cmd_all ;;
  *) die "未知命令 $ACTION" ;;
esac
