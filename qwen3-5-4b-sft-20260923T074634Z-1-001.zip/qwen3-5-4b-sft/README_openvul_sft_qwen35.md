# OpenVul to Qwen3.5-4B SFT

Paths are not hardcoded. Workspace is chosen in this order:

1. OPENVUL_WORKSPACE
2. current working directory if that is unset

Keep these three files in the same folder:

- run_openvul_sft_qwen35.sh
- prepare_sft_qwen35.py
- this README

prepare_sft_qwen35.py is always loaded from the directory of the shell script.

## Run on any machine

```bash
export OPENVUL_WORKSPACE=/abs/path/openvul
export HF_TOKEN=...
mkdir -p "$OPENVUL_WORKSPACE"
bash /path/to/run_openvul_sft_qwen35.sh paths
bash /path/to/run_openvul_sft_qwen35.sh all
```

Split disks if needed:

```bash
export OPEN_VUL_CODE=/ssd/OpenVul
export OPEN_VUL_DATA=/data/openvul/data
export OPEN_VUL_MODELS=/data/openvul/models
```

## Steps

```bash
bash run_openvul_sft_qwen35.sh setup
bash run_openvul_sft_qwen35.sh download
bash run_openvul_sft_qwen35.sh clean
bash run_openvul_sft_qwen35.sh train
```

## Outputs under WORKSPACE

- code/OpenVul
- data/sft_reject
- models/Qwen3.5-4B
- data/sft_qwen35
- code/OpenVul/outputs/Qwen3.5-4B-OpenVul-SFT

rl_query is not SFT supervision. This flow downloads the rejection SFT set.

## Hparams (OpenVul sft.sh)

lr=1e-5, linear, warmup=0.1, wd=0.01, 5 epochs, per-device batch=1, grad acc=8, max_length=32768.

If OOM: export MAX_LEN=16384

Login: hf auth login. Do not use sudo.
